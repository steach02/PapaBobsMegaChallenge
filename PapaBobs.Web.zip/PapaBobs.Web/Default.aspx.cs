﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PapaBobs.DTO.Enums;

namespace PapaBobs.Web
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void orderButton_Click(object sender, EventArgs e)
        {
            if (nameTxtBox.Text.Trim().Length == 0)
            {
                validationLable.Text = "Please enter a name";
                validationLable.Visible = true;
                return;
            }

            if (addressTxtBox.Text.Trim().Length == 0)
            {
                validationLable.Text = "Please enter an address";
                validationLable.Visible = true;
                return;
            }

            if (zipTxtBox.Text.Trim().Length == 0)
            {
                validationLable.Text = "Please enter a zip code";
                validationLable.Visible = true;
                return;
            }

            if (phoneTxtBox.Text.Trim().Length == 0)
            {
                validationLable.Text = "Please enter a phone number";
                validationLable.Visible = true;
                return;
            }
            try
            {
                var order = buildOrder();
                Domain.OrderManager.CreateOrder(order);
                Response.Redirect("success.aspx");
            }
            catch (Exception ex)
            {
                validationLable.Text = ex.Message;
                validationLable.Visible = true;
                return;
            }
            
        }

        private DTO.Enums.PaymentType determinPaymentType()
        {
            DTO.Enums.PaymentType paymentType;
            if (cashRadioButton.Checked)
            {
                paymentType = DTO.Enums.PaymentType.Cash;
            }
            else 
            {
                paymentType = DTO.Enums.PaymentType.Credit;
            }
       
            return paymentType;
        }

        private DTO.Enums.CrustType determinCrust()
        {
            DTO.Enums.CrustType crust;
            if (!Enum.TryParse(crustDropDownList.SelectedValue, out crust))
            {
                throw new Exception("Could dnot determine pizza crust!");
            }
            return crust;
        }

        private DTO.Enums.SizeType determineSize()
        {
            DTO.Enums.SizeType size;
            if (!Enum.TryParse(sizeDropDownList.SelectedValue, out size))
            {
                throw new Exception("Could not determine pizza crust size!" + sizeDropDownList.SelectedValue.ToString());
            }
            return size;
        }

        protected void recalculateTotalCost(object sender, EventArgs e)
        {
            if (sizeDropDownList.SelectedValue.Equals("0")) { validationLable.Text = "you must select a size";  return; }
            if (crustDropDownList.SelectedValue.Equals("0")) { validationLable.Text = "you must select a crust"; return; }

            var order = buildOrder();
            try
            {
                totalLabel.Text = Domain.PizzaPriceManager.calculatePizzaPrice(order).ToString("C");
            }
            catch
            {
                //swallo the error
            }
        }

        private DTO.OrderDTO buildOrder()
        {
            var order = new DTO.OrderDTO();

            order.Size = determineSize();
            order.Crust = determinCrust();
            order.Sausage = sausageCheckBox.Checked;
            order.Onions = onionsCheckBox.Checked;
            order.GreenPeppers = greenPeppersCheckBox.Checked;
            order.Pepperoni = pepperoniCheckBox.Checked;
            order.Name = nameTxtBox.Text;
            order.Address = addressTxtBox.Text;
            order.Zip = zipTxtBox.Text;
            order.Phone = phoneTxtBox.Text;
            order.PaymentType = determinPaymentType();

            return order;
        }
    }
}