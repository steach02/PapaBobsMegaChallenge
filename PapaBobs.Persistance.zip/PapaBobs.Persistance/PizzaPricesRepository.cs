﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapaBobs.Persistance
{
    public  class PizzaPricesRepository
    {
        public static DTO.PizzaPriceDTO GetPizzaPrices()
        {
            var db = new PapaBobsDbEntities();
            var prices = db.PizzaPrices.First();
            var pDTO = convertToDTO(prices);

            return pDTO;
        }
        private static DTO.PizzaPriceDTO convertToDTO(PizzaPrice pizzaPrice)
        {
            var pDTO = new DTO.PizzaPriceDTO();

            pDTO.SmallSizeCost = pizzaPrice.SmallSizeCost;
            pDTO.MediumSizeCost = pizzaPrice.MediumSizeCost;
            pDTO.LargeSizeCost = pizzaPrice.LargeSizeCost;
            pDTO.ThickCrustCost = pizzaPrice.ThickCrustCost;
            pDTO.ThickCrustCost = pizzaPrice.ThickCrustCost;
            pDTO.RegularCrustCost = pizzaPrice.RegularCrustCost;
            pDTO.SausageCost = pizzaPrice.SausageCost;
            pDTO.PepperoniCost = pizzaPrice.PepperoniCost;
            pDTO.OnionsCost = pizzaPrice.OnionsCost;
            pDTO.GreenPeppersCost = pizzaPrice.GreenPeppersCost;

            return pDTO;

        }
    }
}
